package yoga.studio.app;

public class ImgYoga {
    private int ImageId;

     public ImgYoga(int ImageId){
         this.ImageId = ImageId;
     }

    public int getImageId() {
        return ImageId;
    }

    public void setImageId(int ImageId) {
        this.ImageId = ImageId;
    }
}
