package yoga.studio.app;

public class Food2 {
    String foodName2;
    String foodDes2;
    int foodImg2;

    public Food2 (String foodName2, String foodDes2, int foodImg2){
        this.foodName2 = foodName2;
        this.foodDes2 = foodDes2;
        this.foodImg2 = foodImg2;
    }

    public String getFoodName2() {
        return foodName2;
    }

    public void setFoodName2(String foodName2) {
        this.foodName2 = foodName2;
    }

    public String getFoodDes2() {
        return foodDes2;
    }

    public void setFoodDes2(String foodDes2) {
        this.foodDes2 = foodDes2;
    }

    public int getFoodImg2() {
        return foodImg2;
    }

    public void setFoodImg2(int foodImg2) {
        this.foodImg2 = foodImg2;
    }

}
